import { describe, it, expect, vi, beforeEach } from 'vitest';
import { api, setAccessToken, ApiClientError } from '../lib/api';

describe('API Client', () => {
  beforeEach(() => {
    setAccessToken(null);
    vi.clearAllMocks();
  });

  describe('GET requests', () => {
    it('performs a GET request successfully', async () => {
      const mockData = { id: 1, name: 'Test' };
      (global.fetch as any).mockResolvedValueOnce({
        ok: true,
        status: 200,
        json: () => Promise.resolve(mockData),
      });

      const result = await api.get('/api/v1/test');
      expect(result).toEqual(mockData);
      expect(fetch).toHaveBeenCalledWith(
        expect.stringContaining('/api/v1/test'),
        expect.objectContaining({ method: 'GET' }),
      );
    });

    it('includes auth token in headers', async () => {
      setAccessToken('test-token');
      (global.fetch as any).mockResolvedValueOnce({
        ok: true,
        status: 200,
        json: () => Promise.resolve({}),
      });

      await api.get('/api/v1/test');
      expect(fetch).toHaveBeenCalledWith(
        expect.any(String),
        expect.objectContaining({
          headers: expect.objectContaining({
            Authorization: 'Bearer test-token',
          }),
        }),
      );
    });
  });

  describe('POST requests', () => {
    it('performs a POST request with body', async () => {
      const mockData = { success: true };
      (global.fetch as any).mockResolvedValueOnce({
        ok: true,
        status: 201,
        json: () => Promise.resolve(mockData),
      });

      const result = await api.post('/api/v1/test', { name: 'New Item' });
      expect(result).toEqual(mockData);
      expect(fetch).toHaveBeenCalledWith(
        expect.any(String),
        expect.objectContaining({
          method: 'POST',
          body: JSON.stringify({ name: 'New Item' }),
        }),
      );
    });
  });

  describe('Error handling', () => {
    it('throws ApiClientError on non-ok response', async () => {
      (global.fetch as any).mockResolvedValueOnce({
        ok: false,
        status: 404,
        json: () => Promise.resolve({ error: { code: 'not_found', message: 'Not found' } }),
      });

      await expect(api.get('/api/v1/nonexistent')).rejects.toThrow(ApiClientError);
      await expect(api.get('/api/v1/nonexistent')).rejects.toThrow('Not found');
    });

    it('handles 204 No Content', async () => {
      (global.fetch as any).mockResolvedValueOnce({
        ok: true,
        status: 204,
        json: () => {
          throw new Error('No content');
        },
      });

      const result = await api.delete('/api/v1/test');
      expect(result).toBeUndefined();
    });
  });

  describe('Token refresh on 401', () => {
    it('refreshes token on 401 and retries', async () => {
      setAccessToken('expired-token');

      // First response: 401
      (global.fetch as any).mockResolvedValueOnce({
        ok: false,
        status: 401,
        json: () => Promise.resolve({ error: { code: 'unauthorized', message: 'Expired' } }),
      });

      // Refresh token response
      (global.fetch as any).mockResolvedValueOnce({
        ok: true,
        status: 200,
        json: () => Promise.resolve({ access_token: 'new-token' }),
      });

      // Retry response: success
      (global.fetch as any).mockResolvedValueOnce({
        ok: true,
        status: 200,
        json: () => Promise.resolve({ data: 'retried' }),
      });

      const result = await api.get('/api/v1/protected');
      expect(result).toEqual({ data: 'retried' });
    });
  });

  describe('Retry logic', () => {
    it('retries on 500 errors', async () => {
      (global.fetch as any)
        .mockResolvedValueOnce({
          ok: false,
          status: 500,
          json: () => Promise.resolve({ error: { code: 'error', message: 'Server error' } }),
        })
        .mockResolvedValueOnce({
          ok: true,
          status: 200,
          json: () => Promise.resolve({ success: true }),
        });

      const result = await api.get('/api/v1/flaky');
      expect(result).toEqual({ success: true });
      expect(fetch).toHaveBeenCalledTimes(2);
    });
  });
});
