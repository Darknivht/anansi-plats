import { describe, it, expect } from 'vitest';
import {
  cn,
  formatRelativeTime,
  formatCompactNumber,
  formatCents,
  formatPercent,
  truncate,
  generateId,
  formatFileSize,
  parseWikilink,
} from '../lib/utils';

describe('utils', () => {
  describe('cn', () => {
    it('merges class names', () => {
      expect(cn('class1', 'class2')).toBe('class1 class2');
    });

    it('handles conditional classes', () => {
      expect(cn('base', false && 'hidden', 'visible')).toBe('base visible');
    });

    it('handles undefined values', () => {
      expect(cn('a', undefined, 'b')).toBe('a b');
    });

    it('handles empty input', () => {
      expect(cn()).toBe('');
    });
  });

  describe('formatRelativeTime', () => {
    it('returns "just now" for less than 10 seconds', () => {
      expect(formatRelativeTime(new Date())).toBe('just now');
    });

    it('returns seconds ago', () => {
      const date = new Date(Date.now() - 30000);
      expect(formatRelativeTime(date)).toBe('30s ago');
    });

    it('returns minutes ago', () => {
      const date = new Date(Date.now() - 5 * 60 * 1000);
      expect(formatRelativeTime(date)).toBe('5m ago');
    });

    it('returns hours ago', () => {
      const date = new Date(Date.now() - 3 * 60 * 60 * 1000);
      expect(formatRelativeTime(date)).toBe('3h ago');
    });

    it('returns days ago', () => {
      const date = new Date(Date.now() - 2 * 24 * 60 * 60 * 1000);
      expect(formatRelativeTime(date)).toBe('2d ago');
    });

    it('handles string dates', () => {
      const date = new Date(Date.now() - 60000).toISOString();
      expect(formatRelativeTime(date)).toBe('1m ago');
    });
  });

  describe('formatCompactNumber', () => {
    it('formats numbers under 1000', () => {
      expect(formatCompactNumber(999)).toBe('999');
    });

    it('formats thousands', () => {
      expect(formatCompactNumber(1500)).toBe('1.5K');
    });

    it('formats round thousands', () => {
      expect(formatCompactNumber(2000)).toBe('2K');
    });

    it('formats millions', () => {
      expect(formatCompactNumber(2500000)).toBe('2.5M');
    });
  });

  describe('formatCents', () => {
    it('formats dollar amounts', () => {
      expect(formatCents(1999)).toBe('$19.99');
    });

    it('formats whole dollars', () => {
      expect(formatCents(2000)).toBe('$20');
    });

    it('formats zero', () => {
      expect(formatCents(0)).toBe('$0');
    });
  });

  describe('formatPercent', () => {
    it('formats percentages', () => {
      expect(formatPercent(0.756)).toBe('76%');
    });

    it('handles decimal places', () => {
      expect(formatPercent(0.756, 1)).toBe('75.6%');
    });

    it('handles 100%', () => {
      expect(formatPercent(1)).toBe('100%');
    });

    it('handles 0%', () => {
      expect(formatPercent(0)).toBe('0%');
    });
  });

  describe('truncate', () => {
    it('returns text shorter than max length', () => {
      expect(truncate('Hello', 10)).toBe('Hello');
    });

    it('truncates text longer than max length', () => {
      expect(truncate('Hello World This Is Long', 10)).toBe('Hello Worl…');
    });

    it('handles empty string', () => {
      expect(truncate('', 5)).toBe('');
    });
  });

  describe('generateId', () => {
    it('generates a unique string', () => {
      const id1 = generateId();
      const id2 = generateId();
      expect(id1).toBeDefined();
      expect(id1).not.toBe(id2);
    });
  });

  describe('formatFileSize', () => {
    it('formats bytes', () => {
      expect(formatFileSize(500)).toBe('500.0 B');
    });

    it('formats kilobytes', () => {
      expect(formatFileSize(2048)).toBe('2.0 KB');
    });

    it('formats megabytes', () => {
      expect(formatFileSize(1048576)).toBe('1.0 MB');
    });
  });

  describe('parseWikilink', () => {
    it('extracts single wikilink', () => {
      const links = parseWikilink('Check out [[Second Brain]]');
      expect(links).toEqual(['Second Brain']);
    });

    it('extracts multiple wikilinks', () => {
      const links = parseWikilink('[[Project Alpha]] and [[Task Beta]]');
      expect(links).toEqual(['Project Alpha', 'Task Beta']);
    });

    it('returns empty array for no wikilinks', () => {
      const links = parseWikilink('Just regular text');
      expect(links).toEqual([]);
    });

    it('handles empty string', () => {
      const links = parseWikilink('');
      expect(links).toEqual([]);
    });
  });
});
