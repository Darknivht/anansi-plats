type HttpMethod = "GET" | "POST" | "PUT" | "PATCH" | "DELETE";

interface ApiOptions {
  method?: HttpMethod;
  body?: unknown;
  headers?: Record<string, string>;
  params?: Record<string, string | number | boolean | undefined>;
  signal?: AbortSignal;
}

interface ApiError {
  code: string;
  message: string;
  details?: Record<string, unknown>;
  requestId?: string;
}

class ApiClientError extends Error {
  public status: number;
  public code: string;
  public details?: Record<string, unknown>;
  public requestId?: string;

  constructor(status: number, error: ApiError) {
    super(error.message);
    this.name = "ApiClientError";
    this.status = status;
    this.code = error.code;
    this.details = error.details;
    this.requestId = error.requestId;
  }
}

let accessToken: string | null = null;
let refreshPromise: Promise<string | null> | null = null;

export function setAccessToken(token: string | null): void {
  accessToken = token;
}

async function refreshAccessToken(): Promise<string | null> {
  try {
    const res = await fetch(`${getBaseUrl()}/api/v1/auth/refresh`, {
      method: "POST",
      credentials: "include",
      headers: { "Content-Type": "application/json" },
    });
    if (!res.ok) {
      setAccessToken(null);
      return null;
    }
    const data = await res.json();
    const newToken = data.access_token as string;
    setAccessToken(newToken);
    return newToken;
  } catch {
    setAccessToken(null);
    return null;
  }
}

function getBaseUrl(): string {
  return process.env.NEXT_PUBLIC_API_URL ?? "http://localhost:8000";
}

function buildUrl(path: string, params?: Record<string, string | number | boolean | undefined>): string {
  const url = new URL(path.startsWith("http") ? path : `${getBaseUrl()}${path}`);
  if (params) {
    Object.entries(params).forEach(([key, value]) => {
      if (value !== undefined) {
        url.searchParams.set(key, String(value));
      }
    });
  }
  return url.toString();
}

async function request<T>(path: string, options: ApiOptions = {}): Promise<T> {
  const { method = "GET", body, headers = {}, params, signal } = options;

  const requestHeaders: Record<string, string> = {
    ...headers,
  };

  if (accessToken) {
    requestHeaders["Authorization"] = `Bearer ${accessToken}`;
  }

  if (body && !(body instanceof FormData)) {
    requestHeaders["Content-Type"] = "application/json";
  }

  const url = buildUrl(path, params);

  const fetchOptions: RequestInit = {
    method,
    headers: requestHeaders,
    signal,
  };

  if (body) {
    fetchOptions.body = body instanceof FormData ? body : JSON.stringify(body);
  }

  let res = await fetch(url, fetchOptions);

  // ── Token refresh on 401 ──
  if (res.status === 401 && accessToken) {
    if (!refreshPromise) {
      refreshPromise = refreshAccessToken();
    }
    const newToken = await refreshPromise;
    refreshPromise = null;

    if (newToken) {
      requestHeaders["Authorization"] = `Bearer ${newToken}`;
      res = await fetch(url, { ...fetchOptions, headers: requestHeaders });
    } else {
      // Redirect to login
      if (typeof window !== "undefined") {
        window.location.href = "/login";
      }
      throw new ApiClientError(401, {
        code: "unauthorized",
        message: "Session expired. Please log in again.",
      });
    }
  }

  if (!res.ok) {
    let errorBody: ApiError;
    try {
      errorBody = (await res.json()) as { error: ApiError };
      errorBody = (errorBody as unknown as { error: ApiError }).error ?? errorBody;
    } catch {
      errorBody = {
        code: "unknown_error",
        message: `Request failed with status ${res.status}`,
      };
    }
    throw new ApiClientError(res.status, errorBody);
  }

  // Handle 204 No Content
  if (res.status === 204) {
    return undefined as T;
  }

  return res.json() as Promise<T>;
}

/**
 * Retry a request with exponential backoff
 */
async function requestWithRetry<T>(
  path: string,
  options: ApiOptions = {},
  maxRetries = 3,
): Promise<T> {
  for (let attempt = 0; attempt <= maxRetries; attempt++) {
    try {
      return await request<T>(path, options);
    } catch (err) {
      if (attempt < maxRetries && err instanceof ApiClientError && err.status >= 500) {
        const delay = Math.min(1000 * Math.pow(2, attempt), 8000);
        await new Promise((r) => setTimeout(r, delay));
        continue;
      }
      throw err;
    }
  }
  throw new Error("Unreachable");
}

// ── Exported API client ──

export const api = {
  get<T>(path: string, options?: ApiOptions): Promise<T> {
    return requestWithRetry<T>(path, { ...options, method: "GET" });
  },
  post<T>(path: string, body?: unknown, options?: ApiOptions): Promise<T> {
    return requestWithRetry<T>(path, { ...options, method: "POST", body });
  },
  put<T>(path: string, body?: unknown, options?: ApiOptions): Promise<T> {
    return requestWithRetry<T>(path, { ...options, method: "PUT", body });
  },
  patch<T>(path: string, body?: unknown, options?: ApiOptions): Promise<T> {
    return requestWithRetry<T>(path, { ...options, method: "PATCH", body });
  },
  delete<T>(path: string, options?: ApiOptions): Promise<T> {
    return requestWithRetry<T>(path, { ...options, method: "DELETE" });
  },
};

export { ApiClientError };
export type { ApiOptions, ApiError };
